/*
    FreeRTOS V8.2.1 - Copyright (C) 2015 Real Time Engineers Ltd.
    All rights reserved

    VISIT http://www.FreeRTOS.org TO ENSURE YOU ARE USING THE LATEST VERSION.

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation >>!AND MODIFIED BY!<< the FreeRTOS exception.

    >>!   NOTE: The modification to the GPL is included to allow you to     !<<
    >>!   distribute a combined work that includes FreeRTOS without being   !<<
    >>!   obliged to provide the source code for proprietary components     !<<
    >>!   outside of the FreeRTOS kernel.                                   !<<

    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT ANY
    WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
    FOR A PARTICULAR PURPOSE.  Full license text is available on the following
    link: http://www.freertos.org/a00114.html

    1 tab == 4 spaces!

    ***************************************************************************
     *                                                                       *
     *    Having a problem?  Start by reading the FAQ "My application does   *
     *    not run, what could be wrong?".  Have you defined configASSERT()?  *
     *                                                                       *
     *    http://www.FreeRTOS.org/FAQHelp.html                               *
     *                                                                       *
    ***************************************************************************

    ***************************************************************************
     *                                                                       *
     *    FreeRTOS provides completely free yet professionally developed,    *
     *    robust, strictly quality controlled, supported, and cross          *
     *    platform software that is more than just the market leader, it     *
     *    is the industry's de facto standard.                               *
     *                                                                       *
     *    Help yourself get started quickly while simultaneously helping     *
     *    to support the FreeRTOS project by purchasing a FreeRTOS           *
     *    tutorial book, reference manual, or both:                          *
     *    http://www.FreeRTOS.org/Documentation                              *
     *                                                                       *
    ***************************************************************************

    ***************************************************************************
     *                                                                       *
     *   Investing in training allows your team to be as productive as       *
     *   possible as early as possible, lowering your overall development    *
     *   cost, and enabling you to bring a more robust product to market     *
     *   earlier than would otherwise be possible.  Richard Barry is both    *
     *   the architect and key author of FreeRTOS, and so also the world's   *
     *   leading authority on what is the world's most popular real time     *
     *   kernel for deeply embedded MCU designs.  Obtaining your training    *
     *   from Richard ensures your team will gain directly from his in-depth *
     *   product knowledge and years of usage experience.  Contact Real Time *
     *   Engineers Ltd to enquire about the FreeRTOS Masterclass, presented  *
     *   by Richard Barry:  http://www.FreeRTOS.org/contact
     *                                                                       *
    ***************************************************************************

    ***************************************************************************
     *                                                                       *
     *    You are receiving this top quality software for free.  Please play *
     *    fair and reciprocate by reporting any suspected issues and         *
     *    participating in the community forum:                              *
     *    http://www.FreeRTOS.org/support                                    *
     *                                                                       *
     *    Thank you!                                                         *
     *                                                                       *
    ***************************************************************************

    http://www.FreeRTOS.org - Documentation, books, training, latest versions,
    license and Real Time Engineers Ltd. contact details.

    http://www.FreeRTOS.org/plus - A selection of FreeRTOS ecosystem products,
    including FreeRTOS+Trace - an indispensable productivity tool, a DOS
    compatible FAT file system, and our tiny thread aware UDP/IP stack.

    http://www.FreeRTOS.org/labs - Where new FreeRTOS products go to incubate.
    Come and try FreeRTOS+TCP, our new open source TCP/IP stack for FreeRTOS.

    http://www.OpenRTOS.com - Real Time Engineers ltd license FreeRTOS to High
    Integrity Systems ltd. to sell under the OpenRTOS brand.  Low cost OpenRTOS
    licenses offer ticketed support, indemnification and commercial middleware.

    http://www.SafeRTOS.com - High Integrity Systems also provide a safety
    engineered and independently SIL3 certified version for use in safety and
    mission critical applications that require provable dependability.

    1 tab == 4 spaces!
*/

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
#include "stdlib.h"
#include "stdio.h"
/* Xilinx includes. */
#include "xil_printf.h"
#include "xparameters.h"
#include "xil_io.h"

#define RANDOMISATION 2
#define TIMER_ID	1
#define DELAY_10_SECONDS	10000UL
#define DELAY_1_SECOND		1000UL
#define TIMER_CHECK_THRESHOLD	9

/*-----------------------------------------------------------*/

static void TaskGenerator(void *taskgenerators);
//static TimerHandle_t xTimer = NULL;
static TaskHandle_t xTxTask;
void NoRandom(int);
void TaskShuffler(int);
void FineGrainedSwitching(int);
static void prvTxTask( void *pvParameters );
static void TaskGenerator( void *taskgenerators );
/*-----------------------------------------------------------*/

/* The queue used by the Tx and Rx tasks, as described at the top of this
file. */

int NUM_OF_TASKS = 4;

typedef struct Task{
	TaskHandle_t Task;
	int period;
	int deadline;
	int exec_time;
	int tid;
	int V;
	int M;
}TaskFull;

typedef struct Queue{
	int v;
	int M;
	int rem_exec_time;
	int deadline;
	int status;
	int id;
	int cs;
}Q;

typedef struct CandidateQ{
	int rem_exec_time;
	int status;
	int deadline;
	int tid;
	int V;
	int M;
}CQ;

TaskFull TaskSet[4];
Q ReadyQueue[4];
CQ CandidateQueue[4];
TaskFull T_executing;

int stop = 0;//flag to suspend a task or let it execute
int task_executing = 0;//flag to denote whether a task is currently executing
int completed_tasks = 0;
int deadline_miss = 0;
const TickType_t x1second = pdMS_TO_TICKS( DELAY_1_SECOND );


int gcd(int a, int b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}

// Returns LCM of array elements
int findlcm(TaskFull TaskSet[], int NUM_OF_TASKS)
{
    // Initialize result
    int ans = 1;

    // ans contains LCM of arr[0], ..arr[i]
    // after i'th iteration,
    for (int i = 0; i < NUM_OF_TASKS; i++)
    {
        ans = (((TaskSet[i].period * ans))/(gcd(TaskSet[i].period, ans)));
    }
    return ans;
}

void calculate_v(TaskFull TaskSet[],int NUM_OF_TASKS){
	int i,j,divisor,I;
	for (i = 0;i < NUM_OF_TASKS;i++)
	{
		divisor = 0;
		for (j = 0;j < i;j++)
		{
			if (TaskSet[i].period%TaskSet[j].period == 0)
			{
				I = (TaskSet[i].period/TaskSet[j].period)*TaskSet[j].exec_time;
			}
			else
			{
				I = (TaskSet[i].period/TaskSet[j].period + 1)*TaskSet[j].exec_time;
			}
			divisor = divisor + I;
		}
		TaskSet[i].V = TaskSet[i].deadline - (divisor + TaskSet[i].exec_time);
		xil_printf("V = %d\n\r",TaskSet[i].V);
	}
}

void calculate_M(TaskFull TaskSet[],int NUM_OF_TASKS){
	int i,j,found;
	for (i = 0;i < NUM_OF_TASKS;i++){
		found = 0;
		j = i+1;
		while(j < NUM_OF_TASKS && found == 0){
			if(TaskSet[j].V < 0)
			{
				found = 1;
				TaskSet[i].M = TaskSet[j].tid;
			}
			j++;
		}
		if (found == 0)
		{
			TaskSet[i].M = TaskSet[i].tid;
		}
		xil_printf("M = %d\n\r",TaskSet[i].M);
	}
}

int check_ReadyQueue_status(void)
{
	int i,flag = 0;
	for (i = 0;i < NUM_OF_TASKS;i++)
	{
		if (ReadyQueue[i].status == 1)
		{
			flag = 1;
			break;
		}
	}
	return flag;
}

void run_Scheduler(int cur_cycle)
{
	if (T_executing.deadline >= cur_cycle)
	{
		if(T_executing.exec_time > 0)
		{
			//xTaskCreate(TaskGenerator, 					/* The function that implements the task.*/
			//			( const char * ) ((T_executing.tid) + '0'), 		/* Text name for the task, provided to assist debugging only.*/
			//			configMINIMAL_STACK_SIZE, 	/* The stack allocated to the task.*/
			//			NULL, 						/* The task parameter is not used, so set to NULL.*/
			//			tskIDLE_PRIORITY+2,			/* The task runs at the idle priority.*/
			//			&((TaskSet) + T_executing.tid)->Task );
			stop = 0;
			vTaskResume(TaskSet[T_executing.tid].Task);
			vTaskPrioritySet(TaskSet[T_executing.tid].Task, tskIDLE_PRIORITY + 2);
			//RTOS function to create a timer
			//xTimer = xTimerCreate( (const char *) "Timer",x1second,pdFALSE,(void *) TIMER_ID,vTimerCallback);
			//check if timer is created
			//configASSERT( xTimer );
			//start timer
			//xTimerStart( xTimer, 0 );
			xil_printf("Executing Task %d \tCurrent Cycle %d\n\r",T_executing.tid,cur_cycle);
			T_executing.exec_time -= 1;
			//vTaskDelete(TaskSet[T_executing.tid].Task);
		}
	}
	else
	{
		deadline_miss += 1;
	}
	if (T_executing.deadline >= cur_cycle && T_executing.exec_time == 0)
	{
		stop = 1;
		xil_printf("Completed execution: Task %d\n\r",T_executing.tid);
		completed_tasks += 1;
		task_executing = 0;
		vTaskDelete(TaskSet[T_executing.tid].Task);
	}
}

void calculate_rem_v(TaskFull TaskSet[], TaskFull T_executing, int NUM_OF_TASKS)
{
	int j,divisor;
	divisor = 0;
	for (j = 0;j < T_executing.tid;j++)
	{
		if (T_executing.period%TaskSet[j].period == 0)
		{
			divisor = (T_executing.period/TaskSet[j].period)*TaskSet[j].exec_time;
		}
		else
		{
			divisor = (T_executing.period/TaskSet[j].period + 1)*TaskSet[j].exec_time;
		}
		divisor = divisor + TaskSet[j].exec_time;
	}
	T_executing.V = T_executing.period - (divisor + T_executing.exec_time);
}

void contextswitch(void)
{
	ReadyQueue[T_executing.tid].status = 1;
	ReadyQueue[T_executing.tid].rem_exec_time = T_executing.exec_time;
	ReadyQueue[T_executing.tid].deadline = T_executing.deadline;
	ReadyQueue[T_executing.tid].M = T_executing.M;
	ReadyQueue[T_executing.tid].id = T_executing.tid;
	ReadyQueue[T_executing.tid].cs = 1;
	calculate_rem_v(TaskSet,T_executing,NUM_OF_TASKS);
	ReadyQueue[T_executing.tid].v = T_executing.V;
	vTaskPrioritySet(TaskSet[T_executing.tid].Task,tskIDLE_PRIORITY);
	//vTaskDelete(TaskSet[T_executing.tid].Task);
	task_executing = 0;
	stop = 1;
}

int get_index(Q ReadyQueue[], int p)
{
	int i,flag = 0;
	xil_printf("P = %d \n\r",p);
	i = 0;
	while(p > -1)
	{
		if (ReadyQueue[i].status == 1)
		{
			p--;
			flag = 1;
		}
		i++;
	}
	if (flag == 1)
	{
		i--;
	}
	return i;
}

int main( void )
{
	xil_printf("*----------------------*\n\r");
	xil_printf( "TaskShuffler Code Running\n\r" );
	xTaskCreate(prvTxTask, 					/* The function that implements the task. */
				( const char * ) "Tx", 		/* Text name for the task, provided to assist debugging only. */
				configMINIMAL_STACK_SIZE, 	/* The stack allocated to the task. */
				NULL, 						/* The task parameter is not used, so set to NULL. */
	     		tskIDLE_PRIORITY+1,			/* The task runs at the idle priority. */
				&xTxTask );
	vTaskStartScheduler();
	for (;;);
}

static void prvTxTask(void *taskparameters)
{
	//const TickType_t x1second = pdMS_TO_TICKS( DELAY_1_SECOND );
	int hyperperiod;
	int i;

	xil_printf("Scheduler started running\n\r");
	
	//Task Initialisation
	for(i = 0;i < NUM_OF_TASKS;i++)
	{
		//xTaskCreate(TaskGenerator, 					/* The function that implements the task.*/
		//							( const char * ) ((i+1) + '0'), 		/* Text name for the task, provided to assist debugging only.*/
		//							configMINIMAL_STACK_SIZE, 	/* The stack allocated to the task.*/
		//							NULL, 						/* The task parameter is not used, so set to NULL.*/
		//							tskIDLE_PRIORITY,			/* The task runs at the idle priority.*/
		//							&((TaskSet) + i)->Task );
		TaskSet[i].tid = i;
		ReadyQueue[i].status = 0;
	}
	TaskSet[0].period = 5;
	TaskSet[0].deadline = 5;
	TaskSet[0].exec_time = 1;
	TaskSet[1].period = 8;
	TaskSet[1].deadline = 8;
	TaskSet[1].exec_time = 3;
	TaskSet[2].period = 20;
	TaskSet[2].deadline = 20;
	TaskSet[2].exec_time = 4;
	TaskSet[3].period = 40;
	TaskSet[3].deadline = 40;
	TaskSet[3].exec_time = 2;
	hyperperiod = findlcm(TaskSet,NUM_OF_TASKS);
	calculate_v(TaskSet,NUM_OF_TASKS);
	calculate_M(TaskSet,NUM_OF_TASKS);
	if (RANDOMISATION == 1)//call TaskShuffler
	{
		TaskShuffler(hyperperiod);
	}
	else if (RANDOMISATION == 0)//call NoRandom
	{
		NoRandom(hyperperiod);
	}
	else if (RANDOMISATION == 2)
	{
		FineGrainedSwitching(hyperperiod);
	}

	return;

}

static void TaskGenerator( void *taskgenerators )
{
	for (;;)
	{
	xil_printf("Hello World from Task %d \n\r",T_executing.tid);
	vTaskPrioritySet(TaskSet[T_executing.tid].Task, tskIDLE_PRIORITY);
	vTaskSuspend(TaskSet[T_executing.tid].Task);
	//vTaskDelete(TaskSet[T_executing.tid].Task);
	}
}

void NoRandom(int hyperperiod)
{
	int i,j,flag1,flag2,flag3,index_hp,p,counter;

	for (i = 1;i <= 10*hyperperiod;i++)
	{
		flag1 = 0;
		flag2 = 0;
		flag3 = 0;
		for (j = 0;j < NUM_OF_TASKS;j++)
		{
			if (i%TaskSet[j].period == 0)
			{
				/*Add task to the Ready Queue*/
				ReadyQueue[j].status = 1;
				ReadyQueue[j].M = TaskSet[j].M;
				ReadyQueue[j].deadline = i + TaskSet[j].deadline;
				ReadyQueue[j].rem_exec_time = TaskSet[j].exec_time;
				ReadyQueue[j].id = TaskSet[j].tid;
				ReadyQueue[j].v = TaskSet[j].V;
				ReadyQueue[j].cs = 0;
				flag1 = 1;//indicates a new task arrival
				xil_printf("Task %d Arrives at %dth clock cycle\n\r",TaskSet[j].tid,i);
			}
		}
		if (flag1 == 0 && stop == 1)
		{
			flag2 = check_ReadyQueue_status();
			xil_printf("Ready Queue Status is %d\n\r",flag2);//checks whether Ready Queue is empty
		}
		if ((flag1 == 1) || (task_executing == 0 && stop == 1 && (flag1 == 1 || flag2 == 1)))//Run the Shuffler
		{
			if((flag1 == 1 && task_executing == 1 && stop == 0))//there is a task executing in the scheduler
			{
				xil_printf("Context Switch %d \n\r",i);
				contextswitch();//Context Switch to run the scheduler along with the newly arrived tasks
			}
			index_hp = -1;
			j = 0;
			while (index_hp == -1 && j < NUM_OF_TASKS)
			{
				if (ReadyQueue[j].status == 1)
				{
					index_hp = j;
					j = NUM_OF_TASKS;
				}
				j++;
			}
			if (index_hp > -1)
			{
				ReadyQueue[index_hp].status = 0;
				T_executing.exec_time = ReadyQueue[index_hp].rem_exec_time;
				T_executing.tid = index_hp;
				T_executing.M = ReadyQueue[index_hp].M;
				T_executing.V = ReadyQueue[index_hp].v;
				T_executing.deadline = ReadyQueue[index_hp].deadline;
				T_executing.period = TaskSet[index_hp].period;
				stop = 0;
				if (ReadyQueue[index_hp].cs == 0)
				{
						xTaskCreate(TaskGenerator, 					/* The function that implements the task.*/
					           ( const char * ) ((i+1) + '0'), 		/* Text name for the task, provided to assist debugging only.*/
							   configMINIMAL_STACK_SIZE, 	/* The stack allocated to the task.*/
							   NULL, 						/* The task parameter is not used, so set to NULL.*/
							   tskIDLE_PRIORITY,			/* The task runs at the idle priority.*/
				               &((TaskSet) + T_executing.tid)->Task );
							   xil_printf("Task %d Created \n\r",T_executing.tid);
				}
				vTaskSuspend(TaskSet[T_executing.tid].Task);
				task_executing = 1;
			}
		}
		if (task_executing == 1)
		{
			run_Scheduler(i);
		}
		//update ReadyQueue
		for(j = 0;j < NUM_OF_TASKS;j++)
		{
			if(ReadyQueue[j].status == 1)
			{
				if (ReadyQueue[j].deadline < i)
				{
					ReadyQueue[j].status = 0;
					deadline_miss += 1;
				}
			}
		}
	}
	xil_printf("Deadline Miss : %d \n\r",deadline_miss);
	xil_printf("Completed_Tasks : %d \n\r",completed_tasks);
}

void TaskShuffler(int hyperperiod)
{
	int i,j,p;
	//int Num_of_Cycles = hyperperiod;
	int counter = 0;//keeps count of number of tasks in the CandidateQueue
	int flag1 = 0;//flags the arrival of a new task
	int flag2 = 0;//flags the status of ReadyQueue
	int flag3 = 0;//flags if some task in the Ready Queue has value of v negative
	int index_hp,hp,random_index;
	//TaskShuffler
	for (i = 1;i <= 10*hyperperiod;i++)
	{
		flag1 = 0;
		flag2 = 0;
		flag3 = 0;
		for (j = 0;j < NUM_OF_TASKS;j++)
		{
			if (i%TaskSet[j].period == 0)
			{
				/*Add task to the Ready Queue*/
				ReadyQueue[j].status = 1;
				ReadyQueue[j].M = TaskSet[j].M;
				ReadyQueue[j].deadline = i + TaskSet[j].deadline;
				ReadyQueue[j].rem_exec_time = TaskSet[j].exec_time;
				ReadyQueue[j].id = TaskSet[j].tid;
				ReadyQueue[j].v = TaskSet[j].V;
				ReadyQueue[j].cs = 0;
				flag1 = 1;//indicates a new task arrival
				xil_printf("Task %d Arrives at %dth clock cycle\n\r",TaskSet[j].tid,i);
			}
		}
		for (j = 0;j < NUM_OF_TASKS;j++)
		{
			if (ReadyQueue[j].status == 1)
			{
				if (ReadyQueue[j].v < 0)
				{
					flag3 = 1;
					xil_printf("Flag3 = %d\n\r",flag3);
					xil_printf("TaskExecuting = %d\n\r",task_executing);
					xil_printf("stop = %d\n\r",stop);
				}
			}
		}
		if ((flag1 == 0 && stop == 1) || (flag3 == 1))
		{
			flag2 = check_ReadyQueue_status();
			xil_printf("Ready Queue Status is %d\n\r",flag2);//checks whether Ready Queue is empty
		}
		if ((flag3 == 1) || (flag1 == 1) || (task_executing == 0 && stop == 1 && (flag1 == 1 || flag2 == 1)))//Run the Shuffler
		{
			if((flag3 == 1 && task_executing == 1 && stop == 0) || (flag1 == 1 && task_executing == 1 && stop == 0))//there is a task executing in the scheduler
			{
				xil_printf("Context Switch %d \n\r",i);
				contextswitch();//Context Switch to run the scheduler along with the newly arrived tasks
			}
			//TaskShuffler Code
			index_hp = -1;
			j = 0;
			counter = 0;
			//get highest priority task in Ready Queue
			while (index_hp == -1 && j < NUM_OF_TASKS)
			{
				if (ReadyQueue[j].status == 1)
				{
					//Add highest priority task to the Candidate Queue
					CandidateQueue[j].status = 1;
					CandidateQueue[j].rem_exec_time = ReadyQueue[j].rem_exec_time;
					CandidateQueue[j].M = ReadyQueue[j].M;
					CandidateQueue[j].V = ReadyQueue[j].v;
					CandidateQueue[j].deadline = ReadyQueue[j].deadline;
					CandidateQueue[j].tid = ReadyQueue[j].id;
					index_hp = j;
					hp = ReadyQueue[j].M;
					counter++;
				}
				j++;
			}
			if (counter > 0)
			{
				xil_printf("Highest Priority %d \n\r",index_hp);
				counter = 0;
				if (ReadyQueue[index_hp].v > 0)
				{
					//select all eligible jobs from the Ready Queue
					j = index_hp + 1;
					while (j < NUM_OF_TASKS)
					{
						if (ReadyQueue[j].status == 1 && ReadyQueue[j].M >= hp)
						{
							CandidateQueue[j].status = 1;
							CandidateQueue[j].rem_exec_time = ReadyQueue[j].rem_exec_time;
							CandidateQueue[j].M = ReadyQueue[j].M;
							CandidateQueue[j].V = ReadyQueue[j].v;
							CandidateQueue[j].deadline = ReadyQueue[j].deadline;
							CandidateQueue[j].tid = ReadyQueue[j].id;
							if (ReadyQueue[j].v < 0)
							{
								j = NUM_OF_TASKS;
							}
							counter++;
						}
						j++;
					}
				}
				xil_printf("Counter = %d\n\r",counter);
				if (counter == 0)
				{
					//Highest priority task is the only task in the CandidateQueue
					ReadyQueue[index_hp].status = 0;
					CandidateQueue[index_hp].status = 0;
					T_executing.exec_time = CandidateQueue[index_hp].rem_exec_time;
					T_executing.tid = index_hp;
					T_executing.M = CandidateQueue[index_hp].M;
					T_executing.V = CandidateQueue[index_hp].V;
					T_executing.deadline = CandidateQueue[index_hp].deadline;
					T_executing.period = TaskSet[index_hp].period;
					stop = 0;
					if (ReadyQueue[index_hp].cs == 0)
					{
						xTaskCreate(TaskGenerator, 					/* The function that implements the task.*/
					           ( const char * ) ((i+1) + '0'), 		/* Text name for the task, provided to assist debugging only.*/
							   configMINIMAL_STACK_SIZE, 	/* The stack allocated to the task.*/
							   NULL, 						/* The task parameter is not used, so set to NULL.*/
							   tskIDLE_PRIORITY,			/* The task runs at the idle priority.*/
		                       &((TaskSet) + T_executing.tid)->Task );
							   xil_printf("Task %d Created \n\r",T_executing.tid);
					}
					vTaskSuspend(TaskSet[T_executing.tid].Task);
					task_executing = 1;
				}
				else
				{
					p = rand()%counter;//task to be selected from the CandidateQueue
					random_index = get_index(ReadyQueue,p);
					xil_printf("Random Index = %d\n\r",random_index);
					ReadyQueue[random_index].status = 0;
					CandidateQueue[random_index].status = 0;
					T_executing.exec_time = CandidateQueue[random_index].rem_exec_time;
					T_executing.tid = random_index;
					T_executing.M = CandidateQueue[random_index].M;
					T_executing.V = CandidateQueue[random_index].V;
					T_executing.deadline = CandidateQueue[random_index].deadline;
					T_executing.period = TaskSet[random_index].period;
					if (ReadyQueue[random_index].cs == 0)
					{
						xTaskCreate(TaskGenerator, 					/* The function that implements the task.*/
							   ( const char * ) ((i+1) + '0'), 		/* Text name for the task, provided to assist debugging only.*/
							   configMINIMAL_STACK_SIZE, 	/* The stack allocated to the task.*/
						   	   NULL, 						/* The task parameter is not used, so set to NULL.*/
							   tskIDLE_PRIORITY,			/* The task runs at the idle priority.*/
						       &((TaskSet) + T_executing.tid)->Task );
						xil_printf("Task %d Created \n\r",T_executing.tid);
					}
					vTaskSuspend(TaskSet[T_executing.tid].Task);
					stop = 0;
					task_executing = 1;
				}
				//update candidatequeue
				for (j = 0;j < NUM_OF_TASKS;j++)
				{
					if (CandidateQueue[j].status == 1)
					{
						CandidateQueue[j].status = 0;
					}
				}
			}
		}
		if (task_executing == 1)
		{
			run_Scheduler(i);
		}
		//update ReadyQueue
		for(j = 0;j < NUM_OF_TASKS;j++)
		{
			if(ReadyQueue[j].status == 1)
			{
				if (ReadyQueue[j].deadline > i)
				{
					ReadyQueue[j].v -= 1;
				}
				else
				{
					ReadyQueue[j].status = 0;
					deadline_miss += 1;
				}
			}
		}
	}
	xil_printf("Deadline Miss : %d \n\r",deadline_miss);
	xil_printf("Completed_Tasks : %d \n\r",completed_tasks);

}

void FineGrainedSwitching(int hyperperiod)
{
	int i,j,p,quantum = 0;
	//int Num_of_Cycles = hyperperiod;
	int counter = 0;//keeps count of number of tasks in the CandidateQueue
	int flag1 = 0;//flags the arrival of a new task
	int flag2 = 0;//flags the status of ReadyQueue
	int flag3 = 0;//flags if some task in the Ready Queue has value of v negative
	int index_hp,hp,random_index;
	//TaskShuffler with switching
	quantum = rand()%2;
	for (i = 1;i <= 5*hyperperiod;i++)
	{
		flag1 = 0;
		flag2 = 0;
		flag3 = 0;
		for (j = 0;j < NUM_OF_TASKS;j++)
		{
			if (i%TaskSet[j].period == 0)
			{
				/*Add task to the Ready Queue*/
				ReadyQueue[j].status = 1;
				ReadyQueue[j].M = TaskSet[j].M;
				ReadyQueue[j].deadline = i + TaskSet[j].deadline;
				ReadyQueue[j].rem_exec_time = TaskSet[j].exec_time;
				ReadyQueue[j].id = TaskSet[j].tid;
				ReadyQueue[j].v = TaskSet[j].V;
				ReadyQueue[j].cs = 0;
				flag1 = 1;//indicates a new task arrival
				xil_printf("Task %d Arrives at %dth clock cycle\n\r",TaskSet[j].tid,i);
			}
		}
		for (j = 0;j < NUM_OF_TASKS;j++)
		{
			if (ReadyQueue[j].status == 1)
			{
				if (ReadyQueue[j].v < 0)
				{
					flag3 = 1;
					xil_printf("Flag3 = %d\n\r",flag3);
					xil_printf("TaskExecuting = %d\n\r",task_executing);
					xil_printf("stop = %d\n\r",stop);
				}
			}
		}
		if ((flag1 == 0 && stop == 1) || (flag3 == 1) || (quantum <= 0))
		{
			flag2 = check_ReadyQueue_status();
			xil_printf("Ready Queue Status is %d\n\r",flag2);//checks whether Ready Queue is empty
		}
		if ((flag3 == 1) || (quantum <= 0) || (flag1 == 1) || (task_executing == 0 && stop == 1 && (flag1 == 1 || flag2 == 1)))//Run the Shuffler
		{
			if((flag3 == 1 || flag1 == 1 || quantum <= 0) && (task_executing == 1) && (stop == 0))//there is a task executing in the scheduler
			{
				xil_printf("Context Switch %d \n\r",i);
				contextswitch();//Context Switch to run the scheduler along with the newly arrived tasks
			}
			//TaskShuffler Code with switching
			index_hp = -1;
			j = 0;
			counter = 0;
			//get highest priority task in Ready Queue
			while (index_hp == -1 && j < NUM_OF_TASKS)
			{
				if (ReadyQueue[j].status == 1)
				{
					//Add highest priority task to the Candidate Queue
					CandidateQueue[j].status = 1;
					CandidateQueue[j].rem_exec_time = ReadyQueue[j].rem_exec_time;
					CandidateQueue[j].M = ReadyQueue[j].M;
					CandidateQueue[j].V = ReadyQueue[j].v;
					CandidateQueue[j].deadline = ReadyQueue[j].deadline;
					CandidateQueue[j].tid = ReadyQueue[j].id;
					index_hp = j;
					hp = ReadyQueue[j].M;
					counter++;
				}
				j++;
			}
			if (counter > 0)
			{
				xil_printf("Highest Priority %d \n\r",index_hp);
				counter = 0;
				if (ReadyQueue[index_hp].v > 0)
				{
					//select all eligible jobs from the Ready Queue
					j = index_hp + 1;
					while (j < NUM_OF_TASKS)
					{
						if (ReadyQueue[j].status == 1 && ReadyQueue[j].M >= hp)
						{
							CandidateQueue[j].status = 1;
							CandidateQueue[j].rem_exec_time = ReadyQueue[j].rem_exec_time;
							CandidateQueue[j].M = ReadyQueue[j].M;
							CandidateQueue[j].V = ReadyQueue[j].v;
							CandidateQueue[j].deadline = ReadyQueue[j].deadline;
							CandidateQueue[j].tid = ReadyQueue[j].id;
							if (ReadyQueue[j].v < 0)
							{
								j = NUM_OF_TASKS;
							}
							counter++;
						}
						j++;
					}
				}
				xil_printf("Counter = %d\n\r",counter);
				quantum = rand()%2;
				if (counter == 0)
				{
					//Highest priority task is the only task in the CandidateQueue
					ReadyQueue[index_hp].status = 0;
					CandidateQueue[index_hp].status = 0;
					T_executing.exec_time = CandidateQueue[index_hp].rem_exec_time;
					T_executing.tid = index_hp;
					T_executing.M = CandidateQueue[index_hp].M;
					T_executing.V = CandidateQueue[index_hp].V;
					T_executing.deadline = CandidateQueue[index_hp].deadline;
					T_executing.period = TaskSet[index_hp].period;
					stop = 0;
					if (ReadyQueue[index_hp].cs == 0)
					{
						xTaskCreate(TaskGenerator, 					/* The function that implements the task.*/
					           ( const char * ) ((i+1) + '0'), 		/* Text name for the task, provided to assist debugging only.*/
							   configMINIMAL_STACK_SIZE, 	/* The stack allocated to the task.*/
							   NULL, 						/* The task parameter is not used, so set to NULL.*/
							   tskIDLE_PRIORITY,			/* The task runs at the idle priority.*/
		                       &((TaskSet) + T_executing.tid)->Task );
						   xil_printf("Task %d Created \n\r",T_executing.tid);
					}
					vTaskSuspend(TaskSet[T_executing.tid].Task);
					task_executing = 1;
				}
				else
				{
					p = rand()%counter;//task to be selected from the CandidateQueue
					random_index = get_index(ReadyQueue,p);
					xil_printf("Random Index = %d\n\r",random_index);
					ReadyQueue[random_index].status = 0;
					CandidateQueue[random_index].status = 0;
					T_executing.exec_time = CandidateQueue[random_index].rem_exec_time;
					T_executing.tid = random_index;
					T_executing.M = CandidateQueue[random_index].M;
					T_executing.V = CandidateQueue[random_index].V;
					T_executing.deadline = CandidateQueue[random_index].deadline;
					T_executing.period = TaskSet[random_index].period;
					if (ReadyQueue[random_index].cs == 0)
					{
						xTaskCreate(TaskGenerator, 					/* The function that implements the task.*/
							   ( const char * ) ((i+1) + '0'), 		/* Text name for the task, provided to assist debugging only.*/
							   configMINIMAL_STACK_SIZE, 	/* The stack allocated to the task.*/
						   	   NULL, 						/* The task parameter is not used, so set to NULL.*/
							   tskIDLE_PRIORITY,			/* The task runs at the idle priority.*/
						       &((TaskSet) + T_executing.tid)->Task );
						xil_printf("Task %d Created \n\r",T_executing.tid);
					}
					vTaskSuspend(TaskSet[T_executing.tid].Task);
					stop = 0;
					task_executing = 1;
				}
				//update candidatequeue
				for (j = 0;j < NUM_OF_TASKS;j++)
				{
					if (CandidateQueue[j].status == 1)
					{
						CandidateQueue[j].status = 0;
					}
				}
			}
		}
		if (task_executing == 1)
		{
			run_Scheduler(i);
		}
		quantum-= 1;
		//update ReadyQueue
		for(j = 0;j < NUM_OF_TASKS;j++)
		{
			if(ReadyQueue[j].status == 1)
			{
				if (ReadyQueue[j].deadline > i)
				{
					ReadyQueue[j].v -= 1;
				}
				else
				{
					ReadyQueue[j].status = 0;
					deadline_miss += 1;
				}
			}
		}
	}
	xil_printf("Deadline Miss : %d \n\r",deadline_miss);
	xil_printf("Completed_Tasks : %d \n\r",completed_tasks);

}




